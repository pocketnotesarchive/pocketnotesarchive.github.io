<?php
/*
	AbelSoft Pocket Notes support for PHP
	Copyright (C) 2007  Abel Sinkovics (abel@sinkovics.hu)
	Version: 0.1
	
	Documentation and the latest version is available at the Pocket Notes homepage:
		http://pocketnotes.sinkovics.hu
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; version 2 dated June, 1991.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// Read a number from a file
function apn_read_number($f, $bytes) {
	$n = 0;
	$mult = 1;
	while ($bytes>0) {
		$n += ord(fgetc($f)) * $mult;
		$mult *= 256;
		--$bytes;
	}
	return $n;
}

// Write a number to a file
function apn_write_number($f, $number, $bytes) {
	$n = 0;
	while ($bytes>0) {
		fwrite($f, chr($number % 256), 1);
		$number /= 256;
		--$bytes;
	}
}

// Read a string from a file
function apn_read_string($f) {
	$len = apn_read_number($f, 4);
	if ($len<0) return "";
	 else return fread($f, $len);
}

// Write a string to a file
function apn_write_string($f, $s) {
	$len = strlen($s);
	apn_write_number($f, $len, 4);
	if ($len>0) fwrite($f, $s, $len);
}

// Read an ink
function apn_read_ink($f, $bytes_per_coordinate, $offset, &$parameters, $pen_width) {
	// Init
	$ink = array();
	
	// Load the number of the points
	$point_number = apn_read_number($f, 2);
	
	// Process the points
	for ($i=0; $i<$point_number; ++$i) {
		// Read the next point
		$x = apn_read_number($f, $bytes_per_coordinate) + $offset["x"];
		$y = apn_read_number($f, $bytes_per_coordinate) + $offset["y"];
		
		// Append it to the ink
		$ink[] = apn_point($x, $y);
		
		// Calculate the note size
		$x += $pen_width;
		$y += $pen_width;
		if ($x>$parameters["width"]) $parameters["width"]=$x;
		if ($y>$parameters["height"]) $parameters["height"]=$y;
	}
	
	// Done
	return $ink;
}

// Create a color
function apn_color($r, $g, $b) { return array("r"=>$r, "g"=>$g, "b"=>$b); }

// Compare two colors
function apn_colors_equal($a, $b) { return $a["r"]==$b["r"] && $a["g"]==$b["g"] && $a["b"]==$b["b"]; }

// Create a point
function apn_point($x, $y) { return array("x"=>$x, "y"=>$y); }

// Compare two points
function apn_points_equal($a, $b) { return $a["x"]==$b["x"] && $a["y"]==$b["y"]; }

// Returns the 1 digit hexa representation of the number
function apn_hexa_digit($n) {
	switch ($n) {
	case 0: case 1: case 2: case 3: case 4:
	case 5: case 6: case 7: case 8: case 9:
		return "$n";
	case 10: return "A";
	case 11: return "B";
	case 12: return "C";
	case 13: return "D";
	case 14: return "E";
	case 15: return "F";
	}
	return "";
}

// Returns the 2 digit hexa representation of the number
function apn_hexa_number($n) {
	return apn_hexa_digit(floor($n / 16)) . apn_hexa_digit($n % 16);
}

// Convert a color to a html color description
function color_to_html($color) {
	return "#" . apn_hexa_number($color["r"]) . apn_hexa_number($color["g"]) . apn_hexa_number($color["b"]);
}

// Read a color from a file
function apn_read_color($f) {
	$r = apn_read_number($f, 1);
	$g = apn_read_number($f, 1);
	$b = apn_read_number($f, 1);
	return apn_color($r, $g, $b);
}

// Write a color to a file
function apn_write_color($f, $color) {
	apn_write_number($f, $color["r"], 1);
	apn_write_number($f, $color["g"], 1);
	apn_write_number($f, $color["b"], 1);
}

// Read a point from a file
function apn_read_point($f, $byte_per_coordinate) {
	$x = apn_read_number($f, $byte_per_coordinate);
	$y = apn_read_number($f, $byte_per_coordinate);
	return apn_point($x, $y);
}

// Write a point to a file
function apn_write_point($f, $point, $byte_per_coordinate) {
	apn_write_number($f, $point["x"], $byte_per_coordinate);
	apn_write_number($f, $point["y"], $byte_per_coordinate);
}

// Load a 1 version note
function apn_load_file_version_1($f) {
	// Init the note
	$parameters = array();
	$properties = array();
	$elements   = array();
	
	$parameters["width"]  = 0;
	$parameters["height"] = 0;
	$parameters["paper_color"] = apn_color(255, 255, 255);
	$parameters["pattern_color"] = apn_color(0, 0, 0);
	$parameters["pattern_size"] = 1;
	$parameters["pattern_width"] = 1;
	$parameters["paper_type"] = 0;
	
	// Load the number of inks
	$inknum = apn_read_number($f, 4);
	
	// Load the inks
	for ($i=0; $i<$inknum; ++$i) {
		// Create the element
		$element = array();
	
		// Load the pen
		$element["pen_width"] = apn_read_number($f, 4);
		$element["color"]     = apn_read_color($f);
		fgetc($f); // Unused byte
		
		// Other information, not supported by this format
		$element["year"]      = 1960;
		$element["month"]     = 1;
		$element["day"]       = 1;
		$element["hour"]      = 0;
		$element["minute"]    = 0;
		$element["marker"]    = false;
		$element["type"]      = "ink";
		
		// Load the control points
		$data = array();
		$pointnum = apn_read_number($f, 4);
		for ($j=0; $j<$pointnum; ++$j) {
			// Read the point
			$p = apn_read_point($f, 4);
			$data[] = $p;
			
			// Calculate the note size
			$x = $p["x"]+$element["pen_width"];
			$y = $p["y"]+$element["pen_width"];
			if ($x>$parameters["width"]) $parameters["width"]=$x;
			if ($y>$parameters["height"]) $parameters["height"]=$y;
		}
		
		$element["data"]      = $data;
		
		// Append the element
		$elements[] = $element;
	}
	
	// Done
	$note = array(
		"parameters" => $parameters,
		"properties" => $properties,
		"elements"   => $elements
	);
	return $note;
}

// Loads a 2 or 3 version note
function apn_load_file_version_3($f) {
	// Init the note
	$parameters = array();
	$properties = array();
	$elements   = array();
	
	$parameters["width"]  = 0;
	$parameters["height"] = 0;
	$parameters["paper_color"] = apn_color(255, 255, 255);
	$parameters["pattern_color"] = apn_color(0, 0, 0);
	$parameters["pattern_size"] = 1;
	$parameters["pattern_width"] = 1;
	$parameters["paper_type"] = 0;
	
	// The processing variables
	$pen_color = apn_color(0, 0, 0);
	$pen_width = 4;
	$pen_marker = false;
	$offset = apn_point(0, 0);
	$view_offset = apn_point(0, 0);
	$zoom = 1.0;
	$year = 1960;
	$month = 1;
	$day = 1;
	$hour = 0;
	$minute = 0;
	
	// Load the commands
	$processing = true;
	while ($processing && !feof($f)) {
		$command_code = apn_read_number($f, 1);
		switch ($command_code) {
		case   0: $processing=false; break;
		case   1: $pen_color = apn_read_color($f); break;
		case   2: $pen_color = apn_color(  0,   0,   0); break;
		case   3: $pen_color = apn_color(128,   0,   0); break;
		case   4: $pen_color = apn_color(  0, 128,   0); break;
		case   5: $pen_color = apn_color(  0,   0, 128); break;
		case   6: $pen_color = apn_color(128, 128, 128); break;
		case   7: $pen_width = apn_read_number($f, 1); break;
		case   8: $pen_width = 1; break;
		case   9: $pen_width = 2; break;
		case  10: $pen_width = 3; break;
		case  11: $pen_width = 4; break;
		case  12: $offset = apn_read_point($f, 1); break;
		case  13: $offset = apn_read_point($f, 2); break;
		case  14: $offset = apn_read_point($f, 4); break;
		case  15:
		case  16:
		case  17:
			while (true) {
				switch ($command_code) {
				case 15: $data = apn_read_ink($f, 1, $offset, $parameters, $pen_width); break;
				case 16: $data = apn_read_ink($f, 2, $offset, $parameters, $pen_width); break;
				case 17: $data = apn_read_ink($f, 4, $offset, $parameters, $pen_width); break;
				}
				if (empty($data)) break;
				$element = array();
				$element["data"]      = $data;
				$element["pen_width"] = $pen_width;
				$element["color"]     = $pen_color;
				$element["year"]      = $year;
				$element["month"]     = $month;
				$element["day"]       = $day;
				$element["hour"]      = $hour;
				$element["minute"]    = $minute;
				$element["marker"]    = $pen_marker;
				$element["type"]      = "ink";
				$elements[] = $element;
			}
			break;
		case  18: $view_offset = apn_read_point($f, 4); break;
		case  19: $zoom = apn_read_number($f, 4) / 65536; break;
		case  20:
			$pname = apn_read_string($f);
			$properties["$pname"] = apn_read_string($f);
			break;
		case  21: $paper_type = apn_read_number($f, 1); break;
		case  22: $parameters["paper_color"] = apn_read_color($f); break;
		case  23: $parameters["pattern_color"] = apn_read_color($f); break;
		case  24: $parameters["pattern_size"] = apn_read_number($f, 1); break;
		case  25: $parameters["pattern_width"] = apn_read_number($f, 1); break;
		case  26: $pen_marker = true; break;
		case  27: $pen_marker = false; break;
		case  28: $year = apn_read_number($f, 2); break;
		case  29: $month = apn_read_number($f, 1); break;
		case  30: $day = apn_read_number($f, 1); break;
		default:
			if ($command_code>=31 && $command_code<=55) {
				$hour = $command_code - 31;
			} else if ($command_code>=56 && $command_code<=116) {
				$minute = $command_code - 56;
			} else {
				$processing=false;
			}
			break;
		}
	}
	
	// Done
	$note = array(
		"parameters" => $parameters,
		"properties" => $properties,
		"elements"   => $elements
	);
	return $note;
}

// Loads a note file
function apn_load_file($filename) {
	// Open the file
	if (!file_exists("$filename")) return array();
	$f = fopen("$filename", "rb");
	if ($f===false) return array();
	
	// Load the file header
	if (fgetc($f)!='A') return array();
	if (fgetc($f)!='P') return array();
	if (fgetc($f)!='N') return array();
	$version = apn_read_number($f, 1);
	switch ($version) {
	case 1: $note = apn_load_file_version_1($f); break;
	case 2: $note = apn_load_file_version_3($f); break;
	case 3: $note = apn_load_file_version_3($f); break;
	default: $note = array(); break;
	}
	
	// Close the file
	fclose($f);
	
	// Done
	return $note;
}

// Validates a number
function apn_validate_number($n, $min=1, $max=-1) {
	if (!is_scalar($n)) $n = 0;
	if ($min<=$max) {
		if ($n<$min) $n=$min;
		if ($n<$max) $n=$max;
	}
	return $n;
}

// Validates a color
function apn_validate_color($color) {
	if (!is_array($color)) $color = array();
	
	if (!isset($color["r"])) $color["r"] = 0;
	 else $color["r"] = apn_validate_number($color["r"], 0, 255);

	if (!isset($color["g"]) || !is_scalar($color["g"])) $color["g"] = 0;
	 else $color["g"] = apn_validate_number($color["g"], 0, 255);

	if (!isset($color["b"]) || !is_scalar($color["b"])) $color["b"] = 0;
	 else $color["b"] = apn_validate_number($color["b"], 0, 255);
	
	return $color;
}

// Validates an element type
function apn_validate_element_type($type) {
	if (!is_scalar($type)) $type = "";
	switch ($type) {
	case "ink":
		return $type;
	default:
		return "";
	}
}

// Validates a point
function apn_validate_point($point) {
	if (!is_array($point)) $point = array();
	
	if (!isset($point["x"]) || !is_scalar($point["x"])) $point["x"] = 0;
	if (!isset($point["y"]) || !is_scalar($point["y"])) $point["y"] = 0;

	return $point;
}

// Validates a boolean
function apn_validate_boolean($b) {
	if (!is_scalar($b)) return false;
	return $b?true:false;
}

// Validates a note
function apn_validate_note($note) {
	// The note must be an array
	if (!is_array($note)) $note = array();
	
	// The elements of the main array
	if (!isset($note["properties"])) $note["properties"] = array();
	if (!isset($note["parameters"])) $note["parameters"] = array();
	if (!isset($note["elements"]))   $note["elements"] = array();
	
	// Check the properties
	foreach ($note["properties"] as $name=>$value) if (!is_scalar($value)) $note["properties"][$name]="";
	
	// Check the parameters
	$note["parameters"]["width"] = apn_validate_number($note["parameters"]["width"]);
	$note["parameters"]["height"] = apn_validate_number($note["parameters"]["height"]);
	$note["parameters"]["paper_color"] = apn_validate_color($note["parameters"]["paper_color"]);
	$note["parameters"]["pattern_color"] = apn_validate_color($note["parameters"]["pattern_color"]);
	$note["parameters"]["pattern_size"] = apn_validate_number($note["parameters"]["pattern_size"], 0, 255);
	$note["parameters"]["pattern_width"] = apn_validate_number($note["parameters"]["pattern_width"], 0, 255);
	$note["parameters"]["paper_type"] = apn_validate_number($note["parameters"]["paper_type"], 0, 4);
	
	// Check the elements
	foreach ($note["elements"] as $element) {
		$element["type"] = apn_validate_element_type($element["type"]);
		$element["pen_width"] = apn_validate_number($element["pen_width"], 0, 256);
		$element["color"] = apn_validate_color($element["color"]);
		$element["marker"] = apn_validate_boolean($element["marker"]);
		$element["year"] = apn_validate_number($element["year"], 0, 65535);
		$element["month"] = apn_validate_number($element["month"], 1, 12);
		$element["day"] = apn_validate_number($element["day"], 1, 31);
		$element["hour"] = apn_validate_number($element["hour"], 0, 24);
		$element["minute"] = apn_validate_number($element["minute"], 0, 60);
		
		switch ($element["type"]) {
		case "ink":
			if (!is_array($element["data"])) $element["data"] = array();
			foreach ($element["data"] as $point) {
				if (!is_array($point)) $element["data"] = $point = array();
			}
			break;
		}
	}
	
	// Done
	return $note;
}

// Saves a note
function apn_save_resource($f, $note, $version=3) {
	// Check version
	switch ($version) {
	case 1: case 2: case 3:
		break;
	default: return false;
	}
	
	// Validate the note
	$note = apn_validate_note($note);
	
	// Write the header
	$header = "APN" . chr($version);
	fwrite($f, $header);
	
	// Write the content
	switch ($version) {
	case 1:
		// The number of elements
		apn_write_number($f, count($note["elements"]), 4);
		
		// The elements
		foreach ($note["elements"] as $element) {
			// The pen of the element
			apn_write_number($f,  $element["pen_width"], 4);
			apn_write_color($f, $element["color"]);
			apn_write_number($f, 0, 1);
			
			// The points of the element
			apn_write_number($f, count($element["data"]), 4);
			foreach ($element["data"] as $point) apn_write_point($f, $point, 4);
		}
		break;
	case 2: case 3:
		// Write the properties
		foreach ($note["properties"] as $name => $value) {
			apn_write_number($f, 20, 1);
			apn_write_string($f, $name);
			apn_write_string($f, $value);
		}
		
		// Other attributes
		if (isset($note["parameters"]["paper_color"])) {
			apn_write_number($f, 22, 1);
			apn_write_color($f, $note["parameters"]["paper_color"]);
		}
		
		if (isset($note["parameters"]["pattern_color"])) {
			apn_write_number($f, 23, 1);
			apn_write_color($f, $note["parameters"]["pattern_color"]);
		}
		
		if (isset($note["parameters"]["pattern_size"]) && $note["parameters"]["pattern_size"]!=1) {
			apn_write_number($f, 24, 1);
			apn_write_number($f, $note["parameters"]["pattern_size"], 1);
		}
		
		if (isset($note["parameters"]["pattern_width"]) && $note["parameters"]["pattern_width"]!=1) {
			apn_write_number($f, 25, 1);
			apn_write_number($f, $note["parameters"]["pattern_width"], 1);
		}
		
		if (isset($note["parameters"]["paper_type"]) && $note["parameters"]["paper_type"]!=1) {
			apn_write_number($f, 21, 1);
			apn_write_number($f, $note["parameters"]["paper_type"], 1);
		}
		
		// The processing variables
		$pen_color = apn_color(0, 0, 0);
		$pen_width = 4;
		$pen_marker = false;
		$offset = apn_point(0, 0);
		$year = 1960;
		$month = 1;
		$day = 1;
		$hour = 0;
		$minute = 0;
		
		// Write the elements
		$in_node = false;
		foreach ($note["elements"] as $element) {
			// Check the properties
			if ($element["pen_width"]!=$pen_width) {
				if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
			
				switch ($element["pen_width"]) {
				case 1: apn_write_number($f, 8, 1); break;
				case 2: apn_write_number($f, 9, 1); break;
				case 3: apn_write_number($f, 10, 1); break;
				case 4: apn_write_number($f, 11, 1); break;
				default:
					apn_write_number($f, 7, 1);
					apn_write_number($f, $element["pen_width"], 1);
					break;
				}
				$pen_width = $element["pen_width"];
			}
			
			if (!apn_colors_equal($element["color"], $pen_color)) {
				if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
				if ($element["color"]["r"]==0 && $element["color"]["g"]==0 && $element["color"]["b"]==0) {
					apn_write_number($f, 2, 1);
				} else if ($element["color"]["r"]==128 && $element["color"]["g"]==0 && $element["color"]["b"]==0) {
					apn_write_number($f, 3, 1);
				} else if ($element["color"]["r"]==0 && $element["color"]["g"]==128 && $element["color"]["b"]==0) {
					apn_write_number($f, 4, 1);
				} else if ($element["color"]["r"]==0 && $element["color"]["g"]==0 && $element["color"]["b"]==128) {
					apn_write_number($f, 5, 1);
				} else if ($element["color"]["r"]==128 && $element["color"]["g"]==128 && $element["color"]["b"]==128) {
					apn_write_number($f, 6, 1);
				} else {
					apn_write_number($f, 1, 1);
					apn_write_color($f, $element["color"]);
				}
				$pen_color = $element["color"];
			}
			
			if (($element["marker"] && !$pen_marker) || (!$element["marker"] && $pen_marker)) {
				if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
				if ($element["marker"]) apn_write_number($f, 26, 1);
				 else apn_write_number($f, 27, 1);
				$pen_marker = $element["marker"];
			}
		
			if ($version>=3) {
				if ($element["year"]!=$year) {
					if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
					apn_write_number($f, 28, 1);
					apn_write_number($f, $element["year"], 2);
					$year = $element["year"];
				}
			
				if ($element["month"]!=$month) {
					if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
					apn_write_number($f, 29, 1);
					apn_write_number($f, $element["month"], 1);
					$month = $element["month"];
				}
			
				if ($element["day"]!=$day) {
					if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
					apn_write_number($f, 30, 1);
					apn_write_number($f, $element["day"], 1);
					$year = $element["day"];
				}
				
				if ($element["hour"]!=$hour) {
					if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
					apn_write_number($f, $element["hour"] + 31, 1);
					$hour = $element["hour"];
				}
				
				if ($element["minute"]!=$minute) {
					if ($in_node) { apn_write_number($f, 0, 2); $in_node = false; }
				
					apn_write_number($f, $element["minute"] + 56, 1);
					$minute = $element["minute"];
				}
			}
			
			// Write the element itself
			switch ($element["type"]) {
			case "ink":
				// Start a new node if we have to
				if (!$in_node) {
					apn_write_number($f, 17, 1);
					$in_node = true;
				}
				
				// Write this ink
				$pointnum = count($element["data"]);
				if ($pointnum>0) {
					apn_write_number($f, $pointnum, 2);
					foreach ($element["data"] as $point) apn_write_point($f, $point, 4);
				}
				break;
			}
		}
		
		break;
	}
	
	// Done
	return true;
}

// Saves a note
function apn_save_file($filename, $note, $version=3) {
	$f = fopen("$filename", "wb");
	if ($f===false) return false;
	
	$result =  apn_save_resource($f, $note, $version);
	
	fclose($f);
	
	return $result;
}

?>